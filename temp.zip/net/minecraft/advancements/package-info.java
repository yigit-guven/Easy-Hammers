@NullMarked
package net.minecraft.advancements;

import org.jspecify.annotations.NullMarked;
