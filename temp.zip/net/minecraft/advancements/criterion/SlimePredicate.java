package net.minecraft.advancements.criterion;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

public record SlimePredicate(MinMaxBounds.Ints size) implements EntitySubPredicate {
    public static final MapCodec<SlimePredicate> CODEC = RecordCodecBuilder.mapCodec(
        p_468033_ -> p_468033_.group(MinMaxBounds.Ints.CODEC.optionalFieldOf("size", MinMaxBounds.Ints.ANY).forGetter(SlimePredicate::size))
            .apply(p_468033_, SlimePredicate::new)
    );

    public static SlimePredicate sized(MinMaxBounds.Ints p_469277_) {
        return new SlimePredicate(p_469277_);
    }

    @Override
    public boolean matches(Entity p_468050_, ServerLevel p_469697_, @Nullable Vec3 p_469566_) {
        return p_468050_ instanceof Slime slime ? this.size.matches(slime.getSize()) : false;
    }

    @Override
    public MapCodec<SlimePredicate> codec() {
        return EntitySubPredicates.SLIME;
    }
}
