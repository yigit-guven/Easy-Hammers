@NullMarked
package net.minecraft.advancements.criterion;

import org.jspecify.annotations.NullMarked;
