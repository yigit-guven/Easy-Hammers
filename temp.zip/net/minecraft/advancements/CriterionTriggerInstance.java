package net.minecraft.advancements;

import net.minecraft.advancements.criterion.CriterionValidator;

public interface CriterionTriggerInstance {
    void validate(CriterionValidator p_467115_);
}
