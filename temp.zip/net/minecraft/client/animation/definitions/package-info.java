@NullMarked
@OnlyIn(Dist.CLIENT)
package net.minecraft.client.animation.definitions;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
