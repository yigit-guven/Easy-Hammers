package net.minecraft.client;

import com.mojang.serialization.Codec;
import net.minecraft.network.chat.Component;
import net.minecraft.util.StringRepresentable;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum MusicToastDisplayState implements StringRepresentable {
    NEVER("never", "options.musicToast.never"),
    PAUSE("pause", "options.musicToast.pauseMenu"),
    PAUSE_AND_TOAST("pause_and_toast", "options.musicToast.pauseMenuAndToast");

    public static final Codec<MusicToastDisplayState> CODEC = StringRepresentable.fromEnum(MusicToastDisplayState::values);
    private final String name;
    private final Component text;
    private final Component tooltip;

    private MusicToastDisplayState(String p_470711_, String p_470642_) {
        this.name = p_470711_;
        this.text = Component.translatable(p_470642_);
        this.tooltip = Component.translatable(p_470642_ + ".tooltip");
    }

    public Component text() {
        return this.text;
    }

    public Component tooltip() {
        return this.tooltip;
    }

    @Override
    public String getSerializedName() {
        return this.name;
    }

    public boolean renderInPauseScreen() {
        return this != NEVER;
    }

    public boolean renderToast() {
        return this == PAUSE_AND_TOAST;
    }
}
