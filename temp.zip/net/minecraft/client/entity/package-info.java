@NullMarked
@OnlyIn(Dist.CLIENT)
package net.minecraft.client.entity;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
