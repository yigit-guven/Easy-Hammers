package net.minecraft.client;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.network.chat.FormattedText;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class ComponentCollector {
    private final List<FormattedText> parts = Lists.newArrayList();

    public void append(FormattedText p_90676_) {
        this.parts.add(p_90676_);
    }

    public @Nullable FormattedText getResult() {
        if (this.parts.isEmpty()) {
            return null;
        } else {
            return this.parts.size() == 1 ? this.parts.get(0) : FormattedText.composite(this.parts);
        }
    }

    public FormattedText getResultOrEmpty() {
        FormattedText formattedtext = this.getResult();
        return formattedtext != null ? formattedtext : FormattedText.EMPTY;
    }

    public void reset() {
        this.parts.clear();
    }
}
