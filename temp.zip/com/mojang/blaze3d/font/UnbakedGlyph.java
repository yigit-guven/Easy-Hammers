package com.mojang.blaze3d.font;

import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface UnbakedGlyph {
    GlyphInfo info();

    BakedGlyph bake(UnbakedGlyph.Stitcher p_440351_);

    @OnlyIn(Dist.CLIENT)
    public interface Stitcher {
        BakedGlyph stitch(GlyphInfo p_439847_, GlyphBitmap p_440212_);

        BakedGlyph getMissing();
    }
}
